/**
 * Local Revocation Policy Store (v0.7)
 *
 * This is the "policy source" that admin edits locally.
 * When releasing, this gets "frozen" into an immutable signed artifact.
 *
 * Storage: localStorage (MVP) - production should use secure storage.
 */

import type { RevocationRule } from './revocationPolicyTypes';

const LS_LOCAL_REV = 'monolith.local.revocation.rules.v1';

/**
 * Local (editable) revocation policy
 */
export type LocalRevocationPolicy = {
  /** Scope for the policy */
  scope: 'ORG' | 'FACTORY' | 'PROJECT';
  /** Scope ID (required for FACTORY scope) */
  scopeId?: string;
  /** Last update time (ISO) */
  updatedAtIso: string;
  /** Who updated */
  updatedBy: string;
  /** Revocation rules */
  rules: RevocationRule[];
};

/**
 * Get current ISO timestamp
 */
function nowIso(): string {
  return new Date().toISOString();
}

/**
 * Load local policy from storage
 */
function load(): LocalRevocationPolicy {
  const raw = localStorage.getItem(LS_LOCAL_REV);
  if (!raw) {
    return {
      scope: 'ORG',
      updatedAtIso: nowIso(),
      updatedBy: 'local-admin',
      rules: [],
    };
  }
  try {
    const v = JSON.parse(raw);
    if (!v?.rules || !Array.isArray(v.rules)) {
      throw new Error('Invalid policy format');
    }
    return v as LocalRevocationPolicy;
  } catch {
    return {
      scope: 'ORG',
      updatedAtIso: nowIso(),
      updatedBy: 'local-admin',
      rules: [],
    };
  }
}

/**
 * Save local policy to storage
 */
function save(p: LocalRevocationPolicy): void {
  localStorage.setItem(LS_LOCAL_REV, JSON.stringify(p, null, 2));
}

/**
 * Get local revocation policy
 */
export function getLocalRevocationPolicy(): LocalRevocationPolicy {
  return load();
}

/**
 * Set local policy scope
 */
export function setLocalPolicyScope(
  scope: 'ORG' | 'FACTORY' | 'PROJECT',
  scopeId: string | undefined,
  by: string
): void {
  const p = load();
  save({
    ...p,
    scope,
    scopeId,
    updatedAtIso: nowIso(),
    updatedBy: by,
  });
}

/**
 * Add or update a revocation rule
 */
export function upsertLocalRevocationRule(input: {
  keyId: string;
  revokedAtIso: string;
  reason: string;
  by: string;
}): void {
  const p = load();
  const rules = p.rules
    .filter((r) => r.keyId !== input.keyId)
    .concat({
      keyId: input.keyId,
      revokedAtIso: input.revokedAtIso,
      reason: input.reason,
    });
  save({
    ...p,
    updatedAtIso: nowIso(),
    updatedBy: input.by,
    rules,
  });
}

/**
 * Remove a revocation rule
 */
export function removeLocalRevocationRule(keyId: string, by: string): void {
  const p = load();
  save({
    ...p,
    updatedAtIso: nowIso(),
    updatedBy: by,
    rules: p.rules.filter((r) => r.keyId !== keyId),
  });
}

/**
 * Clear all local revocation rules
 */
export function clearLocalRevocationRules(by: string): void {
  const p = load();
  save({
    ...p,
    updatedAtIso: nowIso(),
    updatedBy: by,
    rules: [],
  });
}

/**
 * Clear entire local policy store
 */
export function clearLocalRevocationPolicyStore(): void {
  localStorage.removeItem(LS_LOCAL_REV);
}
