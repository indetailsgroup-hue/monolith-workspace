/**
 * Gate Module Index
 *
 * Validation and enforcement system for cabinet operations
 */

// Existing Gate After Snap
export type {
  GateInput,
  GateReport,
  GateIssue as GateIssueBase,
} from './runGateAfterSnap';
export { runGateAfterSnap } from './runGateAfterSnap';

// Collision Issue Codes
export type {
  CollisionIssueCode,
  IssueSeverity,
  CollisionGateIssue,
} from './collisionIssueCodes';
export {
  COLLISION_ISSUE,
  COLLISION_ISSUE_SEVERITY,
  formatOverlapMessage,
  formatMinGapMessage,
  formatExternalCollisionMessage,
  formatInternalCollisionMessage,
} from './collisionIssueCodes';

// Gate Bundle Types
export type {
  GateIssue,
  GatePerCabinet,
  GateBundleResult,
} from './gateBundleTypes';
export {
  createEmptyBundleResult,
  getAllIssues,
  getIssuesForCabinet,
  getCabinetIdsWithErrors,
  filterBundleByIds,
  mergeBundleResults,
} from './gateBundleTypes';

// Collision to Issues Mapper
export {
  collisionReportToGateIssues,
  collisionPairToGateIssues,
  indexIssuesBySubject,
  getGlobalIssues,
  filterBySeverity,
  hasBlockingIssues,
} from './collisionToIssues';

// Gate Bundle Runner
export type { RunGatePerCabinetFn } from './runGateBundle';
export {
  runGateBundle,
  runGateBundleCollisionOnly,
  isGateBundleBlocked,
  formatGateBundleSummary,
  formatGateBundleIssues,
} from './runGateBundle';
