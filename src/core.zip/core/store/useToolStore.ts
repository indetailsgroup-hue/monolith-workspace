/**
 * ToolStore - Global Tool State Management
 *
 * ARCHITECTURE (North Star v4.0):
 * - Central state for active workspace tool
 * - Coordinates between different tool modules
 * - Handles hotkey-to-tool mapping
 *
 * TOOLS:
 * - select (V): Default selection tool
 * - move (W): Transform - translate
 * - rotate (R): Transform - rotate
 * - scale (S): Transform - scale
 * - uv (U): UV/True-Grain editing
 * - measure (M): Measure 3D distances
 * - glue (G): Face-to-face cabinet alignment
 */

import { create } from 'zustand';
import { immer } from 'zustand/middleware/immer';
import { useMeasureStore } from './useMeasureStore';
import { useGlueStore } from './useGlueStore';
import { useGizmoStore } from './useGizmoStore';

// ============================================
// TYPES
// ============================================

export type ToolId =
  | 'select'
  | 'move'
  | 'rotate'
  | 'scale'
  | 'uv'
  | 'measure'
  | 'glue';

export interface ToolInfo {
  id: ToolId;
  name: string;
  hotkey: string;
  icon: string;
  description: string;
}

export const TOOL_INFO: Record<ToolId, ToolInfo> = {
  select: {
    id: 'select',
    name: 'Select',
    hotkey: 'V',
    icon: '↖',
    description: 'Select objects and faces',
  },
  move: {
    id: 'move',
    name: 'Move',
    hotkey: 'W',
    icon: '✥',
    description: 'Move selected objects',
  },
  rotate: {
    id: 'rotate',
    name: 'Rotate',
    hotkey: 'R',
    icon: '↻',
    description: 'Rotate selected objects',
  },
  scale: {
    id: 'scale',
    name: 'Scale',
    hotkey: 'S',
    icon: '⤢',
    description: 'Scale selected objects',
  },
  uv: {
    id: 'uv',
    name: 'UV Edit',
    hotkey: 'U',
    icon: '⊞',
    description: 'Edit UV mapping / True-Grain',
  },
  measure: {
    id: 'measure',
    name: 'Measure',
    hotkey: 'M',
    icon: '📏',
    description: 'Measure 3D distances',
  },
  glue: {
    id: 'glue',
    name: 'Glue',
    hotkey: 'G',
    icon: '🔗',
    description: 'Align cabinets face-to-face',
  },
};

export interface SnapOptions {
  enabled: boolean;
  gridSize: number;      // mm
  snapToVertex: boolean;
  snapToEdge: boolean;
  snapToFace: boolean;
  snapToGrid: boolean;
}

export interface ToolOptions {
  snap: SnapOptions;
}

export interface ToolState {
  activeTool: ToolId;
  previousTool: ToolId;

  // Tool options (Grid, Snap, etc.)
  options: ToolOptions;

  // Dragging state - tracks which cabinet is being dragged (for TransformControls)
  // When set, Cabinet3D skips position sync to avoid fighting with TransformControls
  draggingCabinetId: string | null;

  // Actions
  setTool: (tool: ToolId) => void;
  toggleTool: (tool: ToolId) => void;
  restorePreviousTool: () => void;

  // Snap actions
  setSnapEnabled: (enabled: boolean) => void;
  setGridSize: (size: number) => void;
  setSnapOptions: (options: Partial<SnapOptions>) => void;

  // Dragging actions
  setDraggingCabinetId: (id: string | null) => void;
}

// ============================================
// STORE
// ============================================

export const useToolStore = create<ToolState>()(
  immer((set, get) => ({
    activeTool: 'select',
    previousTool: 'select',

    // Default options
    options: {
      snap: {
        enabled: true,
        gridSize: 10,        // 10mm default grid
        snapToVertex: true,
        snapToEdge: true,
        snapToFace: false,
        snapToGrid: true,
      },
    },

    // Dragging state
    draggingCabinetId: null,
    
    setTool: (tool) => {
      const current = get().activeTool;

      // Skip if already on this tool (prevents key repeat spam)
      if (current === tool) return;

      // Deactivate current tool
      if (current === 'measure') {
        useMeasureStore.getState().deactivateTool();
      }
      if (current === 'glue') {
        // Only cancel if not already idle (prevents redundant state changes after confirmGlue)
        if (useGlueStore.getState().mode !== 'idle') {
          useGlueStore.getState().cancelGlue();
        }
      }

      // Activate new tool
      if (tool === 'measure') {
        useMeasureStore.getState().activateTool();
      }
      if (tool === 'glue') {
        useGlueStore.getState().startGlue();
      }

      set((state) => {
        state.previousTool = current;
        state.activeTool = tool;
      });

      console.log(`[Tool] Switched to: ${tool}`);
    },
    
    toggleTool: (tool) => {
      const current = get().activeTool;
      if (current === tool) {
        get().restorePreviousTool();
      } else {
        get().setTool(tool);
      }
    },
    
    restorePreviousTool: () => {
      const prev = get().previousTool;
      get().setTool(prev);
    },
    
    // Snap actions
    setSnapEnabled: (enabled) => set((state) => {
      state.options.snap.enabled = enabled;
      console.log(`[Tool] Snap ${enabled ? 'enabled' : 'disabled'}`);
    }),
    
    setGridSize: (size) => set((state) => {
      state.options.snap.gridSize = size;
      console.log(`[Tool] Grid size: ${size}mm`);
    }),
    
    setSnapOptions: (options) => set((state) => {
      Object.assign(state.options.snap, options);
    }),

    // Dragging actions - used by TransformControls to signal when dragging
    setDraggingCabinetId: (id) => set((state) => {
      state.draggingCabinetId = id;
    }),
  }))
);

// ============================================
// HOTKEY HANDLER
// ============================================

export function handleToolHotkey(key: string): boolean {
  const setTool = useToolStore.getState().setTool;

  switch (key.toUpperCase()) {
    case 'V':
      setTool('select');
      return true;
    case 'W':
      setTool('move');
      return true;
    case 'G':
      setTool('glue');
      return true;
    case 'R':
      setTool('rotate');
      return true;
    case 'S':
      setTool('scale');
      return true;
    case 'U':
      setTool('uv');
      return true;
    case 'M':
      setTool('measure');
      return true;
    default:
      return false;
  }
}

// ============================================
// HOOK FOR HOTKEYS
// ============================================

import { useEffect } from 'react';

export function useToolHotkeys() {
  const setTool = useToolStore((s) => s.setTool);
  const activeTool = useToolStore((s) => s.activeTool);
  const cancelMeasurement = useMeasureStore((s) => s.cancelMeasurement);

  // Glue store actions
  const glueMode = useGlueStore((s) => s.mode);
  const cancelGlue = useGlueStore((s) => s.cancelGlue);
  const confirmGlue = useGlueStore((s) => s.confirmGlue);
  const selectFaceByKey = useGlueStore((s) => s.selectFaceByKey);

  useEffect(() => {
    function handler(e: KeyboardEvent) {
      // Ignore if typing in input
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      // Handle Escape
      // IMPORTANT: Read current mode from store directly to avoid stale closure
      if (e.key === 'Escape') {
        const currentGlueMode = useGlueStore.getState().mode;
        // Cancel glue mode if active
        if (currentGlueMode !== 'idle') {
          cancelGlue();
          setTool('select');
          return;
        }
        // Cancel current measurement if in progress
        cancelMeasurement();
        return;
      }

      // Handle Enter for glue confirmation
      // IMPORTANT: Read current mode from store directly to avoid stale closure
      if (e.key === 'Enter') {
        const currentGlueMode = useGlueStore.getState().mode;
        if (currentGlueMode === 'preview') {
          confirmGlue();
          setTool('select');
          return;
        }
      }

      // Handle face selection keys when in glue mode
      // IMPORTANT: Read current state from stores directly to avoid stale closure
      const currentActiveTool = useToolStore.getState().activeTool;
      const currentGlueModeForFaces = useGlueStore.getState().mode;
      if (currentActiveTool === 'glue' && currentGlueModeForFaces !== 'idle') {
        const key = e.key.toLowerCase();
        if (['l', 'r', 'f', 'b', 't', 'o'].includes(key)) {
          const faceMap: Record<string, 'left' | 'right' | 'front' | 'back' | 'top' | 'bottom'> = {
            l: 'left',
            r: 'right',
            f: 'front',
            b: 'back',
            t: 'top',
            o: 'bottom',
          };
          selectFaceByKey(faceMap[key]);
          return;
        }
      }

      // Handle gizmo hotkeys when in move mode
      if (currentActiveTool === 'move') {
        const key = e.key.toUpperCase();
        const gizmoStore = useGizmoStore.getState();

        // L = toggle World/Local space
        if (key === 'L') {
          gizmoStore.toggleSpace();
          return;
        }

        // X/Y/Z = toggle axis constraint
        if (key === 'X' || key === 'Y' || key === 'Z') {
          gizmoStore.toggleAxisOverride(key);
          return;
        }

        // H = toggle HUD
        if (key === 'H') {
          gizmoStore.toggleHUD();
          return;
        }

        // 1 = toggle 1mm step
        if (e.key === '1') {
          gizmoStore.toggleStepMmOverride(1);
          return;
        }

        // 5 = toggle 5mm step
        if (e.key === '5') {
          gizmoStore.toggleStepMmOverride(5);
          return;
        }

        // 0 = toggle 10mm step
        if (e.key === '0') {
          gizmoStore.toggleStepMmOverride(10);
          return;
        }
      }

      // Handle tool hotkeys
      handleToolHotkey(e.key);
    }

    // Handle Shift key for fine/constrain mode (keydown = on, keyup = off)
    function handleKeyUp(e: KeyboardEvent) {
      const currentActiveTool = useToolStore.getState().activeTool;
      if (currentActiveTool === 'move') {
        if (e.key === 'Shift') {
          useGizmoStore.getState().setIsFine(false);
        }
        if (e.key === 'Alt') {
          useGizmoStore.getState().setIsAlt(false);
        }
      }
    }

    function handleModifierDown(e: KeyboardEvent) {
      const currentActiveTool = useToolStore.getState().activeTool;
      if (currentActiveTool === 'move') {
        if (e.key === 'Shift') {
          useGizmoStore.getState().setIsFine(true);
        }
        if (e.key === 'Alt') {
          // Prevent default browser behavior (menu focus)
          e.preventDefault();
          useGizmoStore.getState().setIsAlt(true);
        }
      }
    }

    window.addEventListener('keydown', handler);
    window.addEventListener('keydown', handleModifierDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handler);
      window.removeEventListener('keydown', handleModifierDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [setTool, cancelMeasurement, activeTool, glueMode, cancelGlue, confirmGlue, selectFaceByKey]);
}
