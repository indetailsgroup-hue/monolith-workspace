/**
 * cabinetToDxf.ts - Convert Cabinet Panels to DXF Production Data
 *
 * ARCHITECTURE (North Star v4.0):
 * - Converts CabinetPanel from store to PanelProductionData for DXF export
 * - Auto-generates drilling patterns based on panel role
 * - Supports edge banding layer generation
 *
 * DRILLING PATTERNS:
 * - LEFT_SIDE/RIGHT_SIDE: System 32 shelf pins, back panel groove
 * - TOP/BOTTOM: Confirmat holes for side panels
 * - SHELF: None (adjustable)
 * - DRAWER_FRONT: Hinge cups (35mm)
 * - FRONT: Hinge mounting holes
 *
 * @version 1.0.0
 */

import type { CabinetPanel, Cabinet, GrainDirection as CabinetGrain } from '../types/Cabinet';
import type {
  PanelProductionData,
  MachineOperation,
  EdgeDetail,
  GrainDirection,
  DrillVerticalOp,
  DrillHorizontalOp,
  GrooveOp,
  HingeCupOp,
} from '../types/Production';
import {
  SYSTEM_32,
  CONFIRMAT,
  HINGE_PARAMS,
} from '../types/Production';
import { generatePanelDXF, downloadDXF, DXFGeneratorOptions } from './DXFGenerator';

// ============================================
// TYPES
// ============================================

export interface CabinetDxfOptions extends DXFGeneratorOptions {
  /** Generate System 32 drilling for side panels */
  includeSystem32?: boolean;
  /** Generate back panel groove for side panels */
  includeBackGroove?: boolean;
  /** Generate hinge cups for doors */
  includeHingeCups?: boolean;
  /** Generate confirmat holes for structural panels */
  includeConfirmat?: boolean;
  /** Panel thickness for Z calculations */
  coreThickness?: number;
}

const DEFAULT_OPTIONS: CabinetDxfOptions = {
  includeSystem32: true,
  includeBackGroove: true,
  includeHingeCups: true,
  includeConfirmat: true,
  coreThickness: 18,
  includeDimensions: true,
  includePartInfo: true,
  origin: 'bottom_left',
};

// ============================================
// GRAIN DIRECTION CONVERTER
// ============================================

function convertGrainDirection(grain: CabinetGrain): GrainDirection {
  switch (grain) {
    case 'HORIZONTAL': return 'horizontal';
    case 'VERTICAL': return 'vertical';
    default: return 'none';
  }
}

// ============================================
// EDGE CONVERTER
// ============================================

function convertEdge(edgeMaterialId: string | null, edgeThickness: number = 1.0): EdgeDetail | undefined {
  if (!edgeMaterialId) return undefined;

  return {
    thickness: edgeThickness,
    materialCode: edgeMaterialId,
    height: 23, // Standard edge tape height
  };
}

// ============================================
// DRILLING PATTERN GENERATORS
// ============================================

/**
 * Generate System 32 drilling pattern for side panels
 * Two columns of 5mm holes for adjustable shelves
 */
function generateSystem32Drilling(
  panelWidth: number,
  panelHeight: number,
  _coreThickness: number,
  bottomOffset: number = 100 // Toe kick height
): DrillVerticalOp[] {
  const operations: DrillVerticalOp[] = [];
  const startY = bottomOffset + SYSTEM_32.START_HEIGHT;
  const endY = panelHeight - 64; // Leave 64mm at top

  // Front row
  const frontX = SYSTEM_32.EDGE_OFFSET_FRONT;
  // Back row (from back edge)
  const backX = panelWidth - SYSTEM_32.EDGE_OFFSET_BACK;

  let y = startY;
  let holeIndex = 0;

  while (y <= endY) {
    // Front row hole
    operations.push({
      id: `sys32-front-${holeIndex}`,
      type: 'drill_vertical',
      x: frontX,
      y: y,
      diameter: SYSTEM_32.HOLE_DIAMETER,
      depth: SYSTEM_32.HOLE_DEPTH,
      isThrough: false,
      face: 'A',
    });

    // Back row hole
    operations.push({
      id: `sys32-back-${holeIndex}`,
      type: 'drill_vertical',
      x: backX,
      y: y,
      diameter: SYSTEM_32.HOLE_DIAMETER,
      depth: SYSTEM_32.HOLE_DEPTH,
      isThrough: false,
      face: 'A',
    });

    y += SYSTEM_32.HOLE_SPACING;
    holeIndex++;
  }

  return operations;
}

/**
 * Generate back panel groove for side panels
 * Vertical groove near back edge for inset back panel
 */
function generateBackPanelGroove(
  panelWidth: number,
  panelHeight: number,
  groovePosition: number = 20, // Distance from back edge
  grooveWidth: number = 6,
  grooveDepth: number = 8
): GrooveOp {
  return {
    id: 'back-groove',
    type: 'groove',
    face: 'A',
    axis: 'y', // Vertical groove
    position: panelWidth - groovePosition, // From back edge
    start: 0,
    length: panelHeight,
    width: grooveWidth,
    depth: grooveDepth,
  };
}

/**
 * Generate confirmat screw holes for top/bottom panels
 * Horizontal holes from edges for joining to side panels
 */
function generateConfirmatHoles(
  _panelWidth: number,
  panelHeight: number,
  coreThickness: number,
  _isTop: boolean
): DrillHorizontalOp[] {
  const operations: DrillHorizontalOp[] = [];
  const zCenter = coreThickness / 2;

  // Holes on left edge
  operations.push({
    id: 'confirmat-left-1',
    type: 'drill_horizontal',
    side: 'left',
    offset: CONFIRMAT.EDGE_OFFSET,
    z_center: zCenter,
    diameter: CONFIRMAT.PILOT_DIAMETER,
    depth: CONFIRMAT.EDGE_DEPTH,
  });

  operations.push({
    id: 'confirmat-left-2',
    type: 'drill_horizontal',
    side: 'left',
    offset: panelHeight - CONFIRMAT.EDGE_OFFSET,
    z_center: zCenter,
    diameter: CONFIRMAT.PILOT_DIAMETER,
    depth: CONFIRMAT.EDGE_DEPTH,
  });

  // Holes on right edge
  operations.push({
    id: 'confirmat-right-1',
    type: 'drill_horizontal',
    side: 'right',
    offset: CONFIRMAT.EDGE_OFFSET,
    z_center: zCenter,
    diameter: CONFIRMAT.PILOT_DIAMETER,
    depth: CONFIRMAT.EDGE_DEPTH,
  });

  operations.push({
    id: 'confirmat-right-2',
    type: 'drill_horizontal',
    side: 'right',
    offset: panelHeight - CONFIRMAT.EDGE_OFFSET,
    z_center: zCenter,
    diameter: CONFIRMAT.PILOT_DIAMETER,
    depth: CONFIRMAT.EDGE_DEPTH,
  });

  return operations;
}

/**
 * Generate hinge cup holes for door panels
 * Standard 35mm Blum/Salice hinge cups
 */
function generateHingeCups(
  _panelWidth: number,
  panelHeight: number,
  hingeCount: number = 2
): HingeCupOp[] {
  const operations: HingeCupOp[] = [];

  // Cup X position (from hinge edge - typically left for left-hung door)
  const cupX = HINGE_PARAMS.EDGE_OFFSET + HINGE_PARAMS.CUP_DIAMETER / 2;

  // Calculate Y positions based on door height
  // Top hinge: 100mm from top
  // Bottom hinge: 100mm from bottom
  // Middle hinge(s): evenly spaced
  const topY = panelHeight - 100;
  const bottomY = 100;

  if (hingeCount === 2) {
    operations.push({
      id: 'hinge-cup-top',
      type: 'hinge_cup',
      face: 'B', // Cups drilled from back of door
      x: cupX,
      y: topY,
      diameter: HINGE_PARAMS.CUP_DIAMETER,
      depth: HINGE_PARAMS.CUP_DEPTH,
    });

    operations.push({
      id: 'hinge-cup-bottom',
      type: 'hinge_cup',
      face: 'B',
      x: cupX,
      y: bottomY,
      diameter: HINGE_PARAMS.CUP_DIAMETER,
      depth: HINGE_PARAMS.CUP_DEPTH,
    });
  } else if (hingeCount >= 3) {
    // Three or more hinges
    operations.push({
      id: 'hinge-cup-top',
      type: 'hinge_cup',
      face: 'B',
      x: cupX,
      y: topY,
      diameter: HINGE_PARAMS.CUP_DIAMETER,
      depth: HINGE_PARAMS.CUP_DEPTH,
    });

    operations.push({
      id: 'hinge-cup-bottom',
      type: 'hinge_cup',
      face: 'B',
      x: cupX,
      y: bottomY,
      diameter: HINGE_PARAMS.CUP_DIAMETER,
      depth: HINGE_PARAMS.CUP_DEPTH,
    });

    // Middle hinge
    const middleY = (topY + bottomY) / 2;
    operations.push({
      id: 'hinge-cup-middle',
      type: 'hinge_cup',
      face: 'B',
      x: cupX,
      y: middleY,
      diameter: HINGE_PARAMS.CUP_DIAMETER,
      depth: HINGE_PARAMS.CUP_DEPTH,
    });
  }

  return operations;
}

/**
 * Generate hinge mounting holes for side panels (where hinges attach)
 * 5mm holes for hinge base plate
 * @internal Reserved for future use when cabinet has doors
 */
function _generateHingeMountingHoles(
  _panelWidth: number,
  panelHeight: number,
  _coreThickness: number,
  bottomOffset: number = 100, // Toe kick height
  _doorHeight?: number
): DrillVerticalOp[] {
  const operations: DrillVerticalOp[] = [];

  const mountX = HINGE_PARAMS.MOUNTING_PLATE.EDGE_OFFSET;
  void _doorHeight; // Reserved for variable hinge positioning

  // Top hinge position
  const topY = panelHeight - 100;
  // Bottom hinge position
  const bottomY = bottomOffset + 100;

  // Each hinge plate has 2 mounting holes, 32mm apart
  const holeSpacing = HINGE_PARAMS.MOUNTING_PLATE.HOLE_SPACING;

  // Top hinge mounting holes
  operations.push({
    id: 'hinge-mount-top-1',
    type: 'drill_vertical',
    x: mountX,
    y: topY - holeSpacing / 2,
    diameter: HINGE_PARAMS.MOUNTING_PLATE.HOLE_DIAMETER,
    depth: 13,
    isThrough: false,
    face: 'A',
  });

  operations.push({
    id: 'hinge-mount-top-2',
    type: 'drill_vertical',
    x: mountX,
    y: topY + holeSpacing / 2,
    diameter: HINGE_PARAMS.MOUNTING_PLATE.HOLE_DIAMETER,
    depth: 13,
    isThrough: false,
    face: 'A',
  });

  // Bottom hinge mounting holes
  operations.push({
    id: 'hinge-mount-bottom-1',
    type: 'drill_vertical',
    x: mountX,
    y: bottomY - holeSpacing / 2,
    diameter: HINGE_PARAMS.MOUNTING_PLATE.HOLE_DIAMETER,
    depth: 13,
    isThrough: false,
    face: 'A',
  });

  operations.push({
    id: 'hinge-mount-bottom-2',
    type: 'drill_vertical',
    x: mountX,
    y: bottomY + holeSpacing / 2,
    diameter: HINGE_PARAMS.MOUNTING_PLATE.HOLE_DIAMETER,
    depth: 13,
    isThrough: false,
    face: 'A',
  });

  return operations;
}

// ============================================
// MAIN CONVERTER
// ============================================

/**
 * Convert CabinetPanel to PanelProductionData
 * Auto-generates drilling patterns based on panel role
 */
export function cabinetPanelToProduction(
  panel: CabinetPanel,
  cabinet: Cabinet,
  options: CabinetDxfOptions = {}
): PanelProductionData {
  const opts = { ...DEFAULT_OPTIONS, ...options };
  const coreThickness = opts.coreThickness || 18;

  // Convert edges
  const edges: PanelProductionData['edges'] = {
    top: convertEdge(panel.edges.top),
    bottom: convertEdge(panel.edges.bottom),
    left: convertEdge(panel.edges.left),
    right: convertEdge(panel.edges.right),
  };

  // Start with empty operations
  const operations: MachineOperation[] = [];

  // Generate drilling patterns based on role
  switch (panel.role) {
    case 'LEFT_SIDE':
    case 'RIGHT_SIDE': {
      // System 32 shelf pin holes
      if (opts.includeSystem32) {
        const sys32Ops = generateSystem32Drilling(
          panel.computed.cutWidth,
          panel.computed.cutHeight,
          coreThickness,
          cabinet.dimensions.toeKickHeight
        );
        operations.push(...sys32Ops);
      }

      // Back panel groove
      if (opts.includeBackGroove && cabinet.structure.hasBackPanel) {
        const grooveOp = generateBackPanelGroove(
          panel.computed.cutWidth,
          panel.computed.cutHeight,
          cabinet.manufacturing.backVoid,
          cabinet.manufacturing.backThickness,
          cabinet.manufacturing.grooveDepth
        );
        operations.push(grooveOp);
      }

      // Hinge mounting holes (if cabinet has doors)
      // TODO: Check if cabinet has doors from compartments
      break;
    }

    case 'TOP':
    case 'BOTTOM': {
      // Confirmat holes for joining to sides
      if (opts.includeConfirmat) {
        const isTop = panel.role === 'TOP';
        const confirmatOps = generateConfirmatHoles(
          panel.computed.cutWidth,
          panel.computed.cutHeight,
          coreThickness,
          isTop
        );
        operations.push(...confirmatOps);
      }

      // Back panel groove (for bottom panel)
      if (opts.includeBackGroove && cabinet.structure.hasBackPanel && panel.role === 'BOTTOM') {
        const grooveOp = generateBackPanelGroove(
          panel.computed.cutWidth,
          panel.computed.cutHeight,
          cabinet.manufacturing.backVoid,
          cabinet.manufacturing.backThickness,
          cabinet.manufacturing.grooveDepth
        );
        operations.push(grooveOp);
      }
      break;
    }

    case 'FRONT':
    case 'DRAWER_FRONT': {
      // Hinge cups for doors
      if (opts.includeHingeCups) {
        // Calculate hinge count based on door height
        // Rule: 1 hinge per 762mm (30") of door height, minimum 2
        const hingeCount = Math.max(2, Math.ceil(panel.finishHeight / 762));
        const hingeCupOps = generateHingeCups(
          panel.computed.cutWidth,
          panel.computed.cutHeight,
          hingeCount
        );
        operations.push(...hingeCupOps);
      }
      break;
    }

    case 'SHELF': {
      // Shelves typically have no drilling (adjustable)
      // Could add edge banding notches if needed
      break;
    }

    case 'BACK': {
      // Back panels usually have no drilling
      // Could add ventilation holes if needed
      break;
    }

    case 'DIVIDER': {
      // Dividers may need System 32 on both sides
      if (opts.includeSystem32) {
        const sys32Ops = generateSystem32Drilling(
          panel.computed.cutWidth,
          panel.computed.cutHeight,
          coreThickness,
          cabinet.dimensions.toeKickHeight
        );
        operations.push(...sys32Ops);
      }
      break;
    }

    default:
      // No drilling for unknown panel types
      break;
  }

  // Build production data
  const productionData: PanelProductionData = {
    id: panel.id,
    name: panel.name,
    partNumber: `${cabinet.name.substring(0, 4).toUpperCase()}-${panel.role}`,

    materialId: panel.coreMaterialId,
    surfaceIdA: panel.faces.faceA || undefined,
    surfaceIdB: panel.faces.faceB || undefined,
    grain: convertGrainDirection(panel.grainDirection),

    finishDim: {
      w: panel.finishWidth,
      h: panel.finishHeight,
      t: panel.computed.realThickness,
    },

    cutDim: {
      w: panel.computed.cutWidth,
      h: panel.computed.cutHeight,
      t: coreThickness,
    },

    edges,
    operations,
    quantity: 1,
    cabinetId: cabinet.id,
  };

  return productionData;
}

// ============================================
// BATCH CONVERSION
// ============================================

/**
 * Convert all panels from a cabinet to production data
 */
export function cabinetToProductionPanels(
  cabinet: Cabinet,
  options: CabinetDxfOptions = {}
): PanelProductionData[] {
  return cabinet.panels.map(panel =>
    cabinetPanelToProduction(panel, cabinet, options)
  );
}

/**
 * Generate DXF for a single cabinet panel
 */
export function generateCabinetPanelDXF(
  panel: CabinetPanel,
  cabinet: Cabinet,
  options: CabinetDxfOptions = {}
): string {
  const productionData = cabinetPanelToProduction(panel, cabinet, options);
  return generatePanelDXF(productionData, options);
}

/**
 * Generate all DXF files for a cabinet
 * Returns a Map of filename -> DXF content
 */
export function generateCabinetDXFBundle(
  cabinet: Cabinet,
  options: CabinetDxfOptions = {}
): Map<string, string> {
  const result = new Map<string, string>();

  const productionPanels = cabinetToProductionPanels(cabinet, options);

  productionPanels.forEach((panel, index) => {
    const dxfContent = generatePanelDXF(panel, options);
    const safeRole = panel.partNumber || `PANEL-${index}`;
    const filename = `${cabinet.name}_${safeRole}_${panel.cutDim.t}mm.dxf`;
    result.set(filename, dxfContent);
  });

  return result;
}

/**
 * Download all DXF files for a cabinet
 */
export function downloadCabinetDXF(
  cabinet: Cabinet,
  options: CabinetDxfOptions = {}
): void {
  const dxfBundle = generateCabinetDXFBundle(cabinet, options);

  dxfBundle.forEach((content, filename) => {
    downloadDXF(content, filename);
  });
}

/**
 * Download all DXF files as a single ZIP
 * Requires JSZip library
 */
export async function downloadCabinetDXFZip(
  cabinet: Cabinet,
  options: CabinetDxfOptions = {}
): Promise<void> {
  // Dynamic import for JSZip (tree-shaking friendly)
  const JSZip = (await import('jszip')).default;
  const zip = new JSZip();

  const dxfBundle = generateCabinetDXFBundle(cabinet, options);

  // Create folder for cabinet
  const folder = zip.folder(cabinet.name);
  if (!folder) {
    throw new Error('Failed to create ZIP folder');
  }

  // Add all DXF files
  dxfBundle.forEach((content, filename) => {
    folder.file(filename, content);
  });

  // Generate and download ZIP
  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);

  const link = document.createElement('a');
  link.href = url;
  link.download = `${cabinet.name}_DXF.zip`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

